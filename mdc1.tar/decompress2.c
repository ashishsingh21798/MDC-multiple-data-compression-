#include"header.h"

int decompress2(char*ma)
{
	unsigned int l,cfd,efd, index, val1, val2, val3, val4;
	unsigned char nc,c,c1,c2,c3,byte, byte1, byte2, byte3, byte4, nbyte2, nbyte3, nbyte4;
	printf("...%s...\n", __func__);
	cfd=open("compressed2.txt", O_RDONLY);
	efd=open("decompressed2.txt",O_CREAT|O_RDWR);
	while(1)
	{
		l=read(cfd, &nc, 1);
		if(l==0)
			break;		
		if(nc==3)
			break;
		c1=nc;
		c2=nc;
		c3=nc;
		byte^=byte;
	//	byte|=nc;
//		nc<<=6;
nc>>=6;
byte|=nc;	
	val1=(int)byte;
		byte=*(ma+val1);
		write(efd,&byte,1);
		 if(nc==3)
		{
		//	write(efd, &byte, 1);
			break;
		}
		c1<<=2;
		c1>>=6;
nbyte2^=nbyte2;
		nbyte2|=c1;
		val2=(int)nbyte2;
		byte2=*(ma+val2);
		write(efd,&byte2,1);
		c2<<=4;
		c2>>=6;
nbyte3^=nbyte3;

		nbyte3|=c2;
		val3=(int)nbyte3;
		byte3=*(ma+val3);
		write(efd,&byte3,1);
		c3<<=6;
		c3>>=6;
nbyte4^=nbyte4;
		nbyte4|=c3;
		val4=(int)nbyte4;
		byte4=*(ma+val4);
		write(efd,&byte4,1);
	}
	close(cfd);
	close(efd);
	return 0;
}
