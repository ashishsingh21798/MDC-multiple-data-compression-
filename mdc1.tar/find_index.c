#include"header.h"

int find_index(char *ma, char ch, int ndc)
{
	int i;
	for(i=0;i<ndc;i++)
	{
		if(*(ma+i)==ch)
			return i;
	}
	return 0;
}
