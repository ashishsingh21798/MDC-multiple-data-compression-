#include"header.h"

int compress4(char *ma, int fd)
{
	unsigned int l,efd, cfd, index, ndc, pad;
	unsigned char c, byt,nc ;
	cfd=open("compressed4.txt", O_CREAT|O_RDWR);
	efd=open("ma4.txt", O_CREAT|O_RDWR);		//she laontr
	write(efd, ma, strlen(ma));
	while(1)
	{
		l=read(fd, &nc, 1);
		if(l==0)
			break;		
		if(nc==10)
			break;
		byt^=byt;
		index=find_index(ma, nc, strlen(ma));
		printf("index is%d\n", index);
		sprintf(&c, "%d", index);
		printf("%d", c);
		c<<=4;
		byt|=c;
		read(fd ,&nc, 1);
		if(nc==10)
		{
			int pad=15;
			sprintf(&c,"%d", pad);
			c<<=4;
			c>>=4;
			byt|=c;
			write(cfd, &byt, 1);
			break;
		}
		index=find_index(ma,nc,strlen(ma));
		printf("index is%d\n", index);
		sprintf(&c, "%d", index);
		c<<=4;
		c>>=4;
		byt|=c;
		write(cfd, &byt, 1);
	}
	close(fd);
	close(cfd);
	close(efd);
	return 0;
}
