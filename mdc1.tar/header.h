#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>



int operation(int);
int compression();
int decompression();
char* masterarray();
int unique(char *, char, int);
int find_index(char *, char, int);
int compress2(char*,int);
int compress3(char*,int);
int compress4(char*,int);
int open_file();
int code_length(int);
int decompress4(char*);
int decompress2(char*);
//int compression_type(int);
