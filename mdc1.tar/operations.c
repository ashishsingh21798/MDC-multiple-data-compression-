#include"header.h"

int operation(int choice)
{
	switch(choice)
	{
		case 1:
			compression();
			break;
		case 2 :
			decompression();
			break;
		case 3:
			exit(EXIT_SUCCESS);  
			
	}
return 0;
}

