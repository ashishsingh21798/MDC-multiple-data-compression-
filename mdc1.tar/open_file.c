#include"header.h"

int open_file()
{ 
int fd;
fd=open("file.txt", O_RDWR);
return fd;
}
