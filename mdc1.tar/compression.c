#include"header.h"

int compression()
{
	int ndc, fd, cl;
	char*ma;	
	printf("...Compression...\n");
	fd=open_file();	
	ma=masterarray();
	ndc=strlen(ma);
	cl=code_length(ndc);
	//compression_type(cl);
	 switch(cl)
        {
                case 2:
                        compress2(ma,fd);
                        break;
                case 3:
                        compress3(ma, fd);
                        break;
                case 4:
                        compress4(ma, fd);
                        break;
        }
        return 0;
}
