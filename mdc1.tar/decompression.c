#include"header.h"

int decompression()
{
char *ma;
//int cfd;
	printf("...decompression...");
	//cfd=read("compressed4.txt", &nbyt, 1);
ma=masterarray();	
//decompress4(ma);
decompress2(ma);
	return 0;
}
