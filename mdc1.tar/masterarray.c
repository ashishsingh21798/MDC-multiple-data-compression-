#include"header.h"

char* masterarray()
{
	int fd, count=0, flag;
	char ch;
	char *ma=NULL;
	fd=open("file2.txt", O_RDWR);
	while(1)
	{
		read(fd, &ch, 1);
		if(ch==10)
			break;
		ma=realloc(ma, count+1);
		if(!ma)
		{
			perror("realloc");
			goto OUT;
		}
		flag=unique(ma, ch, count);
		if(flag==1)
		{
			*(ma+count)=ch;
			++count;
		}
	}
	*(ma+count)='\0';
	printf("%s\n", ma);
	return ma;
OUT: return 0;
}


int unique(char *ma, char ch, int count)
{
	while(count)
{
	count--;
	if(*(ma+count)==ch)
		return 0;
}
return 1;
}
