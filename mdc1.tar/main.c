#include"header.h"

int main()
{
	int choice;
	printf("Enter choice\n");
	printf("1. Compression\n");
	printf("2. Decompression\n");
	printf("3. EXIT\n");
	scanf("%d", &choice);
	operation(choice);
	return 0;
}

