#include"header.h"

int compress2(char* ma, int fd)
{
	static unsigned char nc, c, byt;
 	static unsigned int cfd1, efd, index;
	printf("...%s...\n", __func__);
	cfd1=open("compressed2.txt",O_CREAT|O_RDWR);
	printf("cfd1 is %d",cfd1);	
	efd=open("ma2.txt",O_CREAT|O_RDWR);
	write(efd,ma,strlen(ma));
	while(1)
	{
		read(fd,&nc,1);
		if(nc==10)
			break;		
		byt^=byt;
		index=find_index(ma, nc, strlen(ma));
		sprintf(&c, "%d", index);
		c<<=6;
		byt|=c;
		read(fd,&nc,1);
		if(nc==10)
		{
			int pad=3;
			sprintf(&c,"%d",pad);
			c<<=6;
			write(cfd1,&byt,1);	
			break;	
		}
		index=find_index(ma, nc, strlen(ma));
		sprintf(&c, "%d", index);
		c<<=4;
		byt|=c;
		read(fd,&nc,1);
		c<<=2;
		byt|=c;
		index=find_index(ma, nc, strlen(ma));
		sprintf(&c, "%d", index);
		read(fd,&nc,1);
		index=find_index(ma, nc, strlen(ma));
		sprintf(&c, "%d", index);
		byt|=c;
		write(cfd1,&byt,1);	
	}
	close(cfd1);
	close(efd);
	return 0;
}
