#include"header.h"

int decompress4(char*ma)
{
	static unsigned char dc, byte, nbyte;
	static unsigned int l,dfd,cfd, val, val1;
	cfd=open("compressed4.txt", O_RDONLY);			//compressed file in crypted lang
	dfd=open("decompressed4.txt", O_CREAT|O_RDWR);
	while(1)
	{
		l=read(cfd,&dc,1);
		if(l==0)
			break;
		if(dc==10)
			break;
		byte^=byte;
		byte=dc;
		byte>>=4;
		val= (int) byte;
		byte=*(ma+val);		
		printf("%c", byte);
		write(dfd, &byte, 1);
		dc<<=4;
		dc>>=4;
if(l==0)
break;		
if(dc==15)
		//	break;
		goto OUT;
		val1= (int) dc;
		nbyte^=nbyte;
		nbyte=*(ma+val1);
		//	if(dc==15)
		//		break;
		printf("%c", nbyte);
		write(dfd, &nbyte, 1);

	}
	close(cfd);
	close(dfd);
	return 0;
OUT : nbyte='\n';
write(dfd, &nbyte, 1);
return 0;
}
