#include"header.h"

int code_length(int ndc)
{
	if(ndc>0 && ndc<5)
		return 2;
	if(ndc>4 && ndc<9)
		return 3;
	if(ndc>8 && ndc<17)
		return 4;

	return 0;
}
